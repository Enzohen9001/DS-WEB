/*Escreva em JavaScript um programa que realize a conversão de uma temperatura
fornecida em graus Fahrenheit (F) para Celsius (C).*/
let num = prompt ("escreva quantos graus fahrenhight esta para fazer a converção para celcius.")

alert("Olá, esta " + (num - 32) * 0.5556 + " graus celcius")