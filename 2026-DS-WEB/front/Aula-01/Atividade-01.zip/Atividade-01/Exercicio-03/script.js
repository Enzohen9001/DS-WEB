let num = Number (prompt ("Qual é o numero que você quer elevar ao cubo?"))


alert("Olá, o seu resultado é " + num * num * num + "!")