let num1 = Number (prompt ("Coloque o primeiro numero para a soma?"))
let num2 = Number (prompt ("Coloque o segundo numero para a soma?"))

if (num1  == null) {
    alert("Você cancelou, caso queira colocar seu nome recarregue a pagina se não apenas aperte ok e continue.")
} else {
    alert(num1 + num2)
}

let num3 = Number (prompt ("Coloque o primeiro numero para a subtração?"))
let num4 = Number (prompt ("Coloque o segundo numero para a subtração?"))

if (num3  == null) {
    alert("Você cancelou, caso queira colocar seu nome recarregue a pagina se não apenas aperte ok e continue.")
} else {
    alert(num3 - num4)
}

let num5 = Number (prompt ("Coloque o primeiro numero para a multiplicação?"))
let num6 = Number (prompt ("Coloque o segundo numero para a multiplicação?"))

if (num5  == null) {
    alert("Você cancelou, caso queira colocar seu nome recarregue a pagina se não apenas aperte ok e continue.")
} else {
    alert(num5 * num6)
}

let num7 = Number (prompt ("Coloque o primeiro numero para a divisão?"))
let num8 = Number (prompt ("Coloque o segundo numeropara a divisão?"))

if (num7  == null) {
    alert("Você cancelou, caso queira colocar seu nome recarregue a pagina se não apenas aperte ok e continue.")
} else {
    alert(num7 / num8)
}